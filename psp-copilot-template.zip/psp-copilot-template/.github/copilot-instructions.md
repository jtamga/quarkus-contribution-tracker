# Instructions Copilot - Equipe MIC PSP

## Contexte du projet

PSP_Prescriptions est un module de l'application **Ideomed** (domaine sante / hospitalier) qui gere les **prescriptions de medicaments et d'oxygenotherapie**. Le projet est developpe par l'equipe **MIC PSP** (Maincare).

Le groupId Maven est `com.sqli.sante.ideomed.prescription`.

## Architecture du projet

Le projet est un **multi-module Maven** avec un packaging **EAR** deploye sur **JBoss/WildFly**. Il utilise les technologies **Java EE** (EJB, JPA, JAX-RS, CDI).

### Modules principaux

| Module | Role |
|--------|------|
| `PSP_PrescriptionsEJB` | Logique metier (EJB Stateless). Contient les services metier : prescription, conciliation, base scientifique, synthese, stupefiants, protocoles, etc. |
| `PSP_PrescriptionsEJBJPA` | Couche persistance JPA (entites, DAOs). Contient les entites auditees (Hibernate Envers). |
| `PSP_PrescriptionsWeb` | Application web principale (WAR) - front-end TypeScript/Less pour les prescriptions de medicaments. |
| `PSP_PrescriptionsO2Web` | Application web (WAR) - front-end TypeScript/Less pour les prescriptions de gaz (oxygenotherapie). |
| `PSP_PrescriptionsCsgWeb` | Application web (WAR) - front-end TypeScript/Less pour les prescriptions de consignes. |
| `PSP_PrescriptionsPrivateClient` | Client EJB prive (interfaces internes au module). |
| `PSP_PrescriptionsSharedWithPserver` | Classes partagees entre PSP_Prescriptions et le pserver (ideomed_pserver). |
| `PSP_PrescriptionsUnit` | Bootstrap et utilitaires pour les tests unitaires. |
| `prescriptions-api-private` | API REST privee (JAX-RS, WAR). |
| `prescriptions-api-public` | API REST publique (JAX-RS, WAR). |
| `prescriptions-datadirectory` | Data directory (WAR) - configuration externalisee. |
| `PSP_PrescriptionsEAR` | Packaging EAR pour le deploiement. |
| `PSP_PrescriptionsModule` | Module de livraison (assembly tar.gz). |

### Arborescence du module PSP_Prescriptions

> L'arborescence detaillee des packages et modules est disponible dans [arborescence.md](arborescence.md).
>
> Pour l'inclure dans le contexte Copilot lors d'une session de chat, utilisez : `#file:.github/arborescence.md`

### Projet externe associe

- **PSP_PrescriptionsClient** : Client EJB public (interfaces exposees aux autres modules Ideomed). Projet separe avec son propre depot.
- **ideomed_pserver** : Le serveur principal Ideomed (DMECOM, DMEEJB, DMEEJBClient, DMEJPA, DMEWJA).

## Packages Java principaux

- `com.maincare.*` - Code metier recent (nouveau namespace Maincare)
- `com.sqli.sante.*` - Code metier historique (ancien namespace SQLI)
- `com.ideosante.*` - Code socle / framework
- `com.ideomed.*` - Code legacy

## Conventions de code

### Java

- **Encodage** : ISO-8859-1 (defini dans le POM parent).
- **Annotations Lombok** : utiliser `@Getter`, `@Setter`, `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor`, `@ToString`, `@EqualsAndHashCode` quand c'est pertinent pour reduire le boilerplate.
- **EJB** : les services metier sont des `@Stateless` beans. L'injection se fait via `@EJB` ou `@Inject`.
- **JPA** : les entites utilisent les annotations JPA standard (`@Entity`, `@Table`, `@Column`, etc.). L'audit est gere par **Hibernate Envers** (`@Audited`).
- **Suffixes de classes** :
  - `*Entity` / `*EntityImpl` / `*EntityLazy` : entites JPA
  - `*Pojo` / `*DTO` / `*Holder` : objets de transfert
  - `*Bean` : EJB
  - `*Service` : services metier
  - `*Facade` : facades REST (JAX-RS)
- **Tests unitaires** : JUnit 4 + Mockito/PowerMock + AssertJ. Les classes de test d'integration suivent le pattern `*IntegrationTst.java`.
- **Couverture** : JaCoCo. Les classes `*Pojo`, `*Entity`, `*EntityImpl`, `*EntityLazy`, `*DTO`, `*Holder` sont exclues de la couverture.

### Front-end (TypeScript / Less)

- **Langage** : TypeScript (compile via `tsc`).
- **Styles** : Less.
- **Gestionnaire de paquets** : pnpm.
- **Formatage** : Prettier (configuration dans `prettier.config.js`).
- **Framework** : `@mcs-fwk/forms3` (framework interne MCS).
- **Commandes de developpement** :
  - `pnpm run dev` : mode watch (compilation TS + Less + Prettier).
  - `pnpm run build` : build complet.
  - `pnpm run compile-ts` : compilation TypeScript seule.
  - `pnpm run compile-less` : compilation Less seule.

## Commandes Maven utiles

```bash
# Compilation complete sans tests, avec dezip des ressources web
mvn clean install -U -Dmaven.test.skip=true -Dwar.unzip-web.skip=false -Dwebclient.unpack=true -T 4

# Lancer tous les tests unitaires
mvn test

# Tests unitaires sans la base scientifique
mvn package -PxbaseScientifique

# Tests d'integration
mvn test -Pintegration-tests
```

## Regles pour Copilot

1. **Langue** : les commentaires de code, les messages de log et la documentation doivent etre rediges en **francais**.
2. **Ne pas modifier les fichiers generes** : les fichiers dans les dossiers `src/gen/` sont auto-generes et ne doivent pas etre modifies manuellement.
3. **Respecter l'architecture en couches** :
   - `PSP_PrescriptionsEJBJPA` - acces aux donnees (entites, DAOs)
   - `PSP_PrescriptionsEJB` - logique metier (services)
   - `prescriptions-api-*` - exposition REST
   - `PSP_Prescriptions*Web` - interface utilisateur
4. **Tests** : tout nouveau code metier doit etre accompagne de tests unitaires (JUnit 4 + Mockito + AssertJ). Placer les tests dans `src/test/java` avec le meme package que la classe testee.
5. **Pas de logique metier dans les couches Web ou API** : les controleurs REST et les composants web doivent deleguer au EJB metier.
6. **Utiliser les DTOs** pour les echanges entre couches (ne pas exposer les entites JPA directement dans les APIs REST).
7. **Logging** : utiliser SLF4J pour le logging.
8. **Gestion des exceptions** : ne pas avaler les exceptions silencieusement. Logger et/ou remonter les erreurs de maniere appropriee.