# Arborescence du module PSP_Prescriptions

```
PSP_Prescriptions/
  .github/                          # Instructions Copilot et prompts
  prescriptions-api-private/        # API REST privee (JAX-RS, WAR)
   src/main/java/
     com/maincare/ws/
       pn13/                       # Endpoints PN13 (emission, reception, ack)
       devicemanager/              # Gestion des dispositifs
       livret/                     # Import du livret
  prescriptions-api-public/         # API REST publique (JAX-RS, WAR)
   src/main/java/
     com/maincare/ws/ordonnance/   # Endpoints ordonnances publics
  prescriptions-datadirectory/      # Data directory - configuration externalisee
   src/main/java/
     com/maincare/
       datadirectory/              # Bean, BO, data (entree/hospit/sejour/sortie)
       ws/                         # Endpoints REST du data directory
  PSP_PrescriptionsCsgWeb/          # WAR front-end prescriptions de consignes (TS/Less)
  PSP_PrescriptionsEAR/             # Packaging EAR pour deploiement JBoss/WildFly
  PSP_PrescriptionsEJB/             # Logique metier (EJB Stateless)
   src/main/java/
     com/ideosante/
       consigne/medicale/service/  # Service consignes medicales
       gaz/service/                # Service prescriptions de gaz
       impression/                 # Gestion impression
       kafka/listener/             # Listener Kafka
       tracable/orika/             # Mapping Orika tracable
     com/maincare/
       analyseordonnance/service/  # Analyse d'ordonnances
       bureautique/                # Generation documents bureautiques
       changementmarche/cron/      # Cron changement de marche
       importlivret/service/       # Import livret therapeutique
       mic/prescription/pharmacie/ # Pharmacie MIC (worklist, filtre)
       modedegrade/service/        # Mode degrade
       perso/                      # Personnalisation (cohabitation, prescription med)
       pn13/                       # Services PN13 (administration, pharmacie, prescription)
       prescription/               # Services prescription (paretiquette, etc.)
       protocole/modification/     # Modification protocoles
       reconnaissance/ordonnance/  # Reconnaissance d'ordonnances
     com/sqli/sante/
       configuration/service/      # Configuration
       datadirectory/              # Acces data directory
       pharmacie/analysepharmacie/ # Analyse pharmaceutique
       prescription/
         basescientifique/         # Base scientifique (Vidal, VidalInt)
         conciliation/             # Conciliation medicamenteuse
         evenement/futur/          # Evenements futurs
         pds/generic/              # Plan de soins generique (med, perfusion, externe)
         service/                  # Services principaux prescription
           alerte/                 # Alertes
           bmo/                    # BMO
           cloture/                # Cloture de prescription
           conciliation/           # Conciliation (a posteriori)
           detail/                 # Detail prescription
           droit/signature/        # Droits de signature
           historique/             # Historique
           synthese/               # Synthese prescriptions
           worklist/               # Worklist
         stupefiant/service/       # Stupefiants
         synthese/service/         # Synthese
       topshoraires/               # Tops horaires
  PSP_PrescriptionsEJBJPA/          # Couche persistance JPA (entites, DAOs)
   src/main/java/
     com/ideomed/
       core/                       # Core commun (domain, repository, webservice)
       inlog/pserver/db/           # Entites DB pserver (changementmarche, medecin, socle)
       sqli/sante/prescription/db/ # Entites prescription (analyse, avis, config,
                                   #   medicament, pharmacie, surveillance, etc.)
     com/ideosante/
       audit/                      # Audit Envers
       consigne/medicale/          # Entites consignes (domain, mapper, repository)
       gaz/                        # Entites gaz (builder, domain, mapper, repository)
       pn13/                       # Entites PN13 (ack, repository)
     com/maincare/
       bureautique/                # Entites bureautique
       protocole/modification/     # Entites protocoles
       reconnaissance/ordonnance/  # Entites reconnaissance ordonnances
  PSP_PrescriptionsModule/          # Module de livraison (assembly tar.gz)
  PSP_PrescriptionsO2Web/           # WAR front-end prescriptions de gaz/O2 (TS/Less)
  PSP_PrescriptionsPrivateClient/   # Client EJB prive (interfaces internes)
  PSP_PrescriptionsSharedWithPserver/ # Classes partagees avec ideomed_pserver
   src/main/java/
     com/ideosante/
       cdi/                        # CDI factories et qualifiers
       consigne/medicale/dto/      # DTOs consignes
       gaz/dto/                    # DTOs gaz (audit, protocole, releve)
       prescription/               # DTOs prescription (bmo, conciliation, plansoin)
     com/maincare/
       bo/pharmacie/               # BO pharmacie
       perso/dto/                  # DTOs personnalisation
       prescription/               # DTOs impression, CDI prescription
       reconnaissance/ordonnance/  # JWT reconnaissance ordonnances
     com/sqli/sante/
       analysepharma/              # DTOs analyse pharmaceutique
       prescription/dto/           # DTOs prescription (medicament, conciliation,
                                   #   pds, synthese, sorties, etc.)
       protocoles/                 # DTOs protocoles
  PSP_PrescriptionsUnit/            # Bootstrap et utilitaires tests unitaires
   src/main/java/
     com/ideosante/bootstrap/      # Bootstrap CDI/EJB pour tests
  PSP_PrescriptionsWeb/             # WAR front-end prescriptions medicamenteuses (TS/Less)
   src/main/java/                  # Controllers Struts/Spring + services web
   src/modules/webapp/             # Ressources web (TS, Less, JSP, JS)
   src/test/java/                  # Tests unitaires controllers
```
