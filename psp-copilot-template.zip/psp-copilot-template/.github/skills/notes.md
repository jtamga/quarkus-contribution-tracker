#  Un dossier skills, ça contient quoi ?

Le dossier skills contient des capacites techniques reutilisables, independantes du contexte.

💡 Un skill = "ce que l'IA sait faire parfaitement"

✅ Concrètement : contenu d'un skill

1. 🎯 Objectif
Ce que permet le skill
2. 📏 Regles / methode
Comment executer correctement cette competence
3. 🧾 Etapes
Processus a suivre
4. ✅ Criteres de qualite
Quand le travail est considere comme "bon"
5. 📦 Output attendu
Format de reponse