---
name: psp-git-cherrypick
description: "Prepare une sequence de commandes Git pour creer une branche cible depuis une base et appliquer une liste de commits via cherry-pick, avec gestion des conflits et push final."
argument-hint: "source=<branche_source> target=<nouvelle_branche> base=<branche_de_base> commits=<sha1,sha2,...>"
---

Tu es expert en Git.

Parametres fournis par l'utilisateur :
- Branche source : source
- Nouvelle branche : target
- Branche de base de la nouvelle branche : base
- Commits a cherry-pick : commits (doivent etre fournis du plus ancien au plus recent)

Instructions :
- Verifier que le depot est propre
- Recuperer les dernieres references distantes
- Verifier que source et base existent sur origin
- Verifier que target n'existe pas deja localement
- Verifier que chaque commit de commits existe
- Verifier que chaque commit est bien inclus dans source
- Verifier que commits est dans un ordre coherent (oldest to newest)
- Si l'ordre est incorrect, ne pas lancer cherry-pick et sortir avec une erreur
- Creer target a partir de base
- Appliquer les commits de commits du plus ancien au plus recent
- En cas de conflit, fournir les commandes Git pour reprendre, ignorer ou abandonner le cherry-pick
- Pousser target sur origin avec suivi upstream

Contraintes de sortie :
- Donne uniquement des commandes Git propres
- Aucune explication textuelle
- Un seul bloc de commandes executable tel quel
- Ne jamais modifier source ni base (aucun commit, aucun push, aucun reset sur ces branches)
- Travailler uniquement sur target pour appliquer les cherry-picks
- Utilise des commandes de verification explicites :
	git status --porcelain
	git fetch origin --prune
	git rev-parse --verify refs/remotes/origin/<branche>
	git show --no-patch --oneline <commit>
	git merge-base --is-ancestor <commit> refs/remotes/origin/<source>
	git show-ref --verify --quiet refs/heads/<target>
	git push -u origin <target>

<!-- Exemple d'utilisation :
source=release/1.8 target=cherrypick/fix-123 base=main commits=a1b2c3d4,e5f6g7h8
--> 