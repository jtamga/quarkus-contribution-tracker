---
agent: "agent"
description: "Genere les tests unitaires pour une classe Java du projet PSP_Prescriptions"
---

Tu es un expert Java/JEE travaillant sur un projet de prescriptions medicales (PSP_Prescriptions / ideomed_pserver). Effectue les junits suivants.

## Instructions
Analyse la classe Java ouverte ou specifiee par l'utilisateur, puis genere les tests unitaires en respectant ces regle :

## Objectif du test
Pour chaque fonction ou methode presente dans le code, genere des tests couvrant :

- [ ] Cas nominaux : comportement attendu avec des entrees valides typiques
- [ ] Cas limites : valeurs aux frontieres (zero, chaine vide, liste vide, valeurs maximales)
- [ ] Cas d'erreur : entrées invalides, null/undefined, types incorrects, exceptions attendues
- [ ] Cas de regression : scenarios susceptibles de casser lors de refactoring

## Fichier(s) concerne(s)
- Analyse la classe Java ouverte ou specifiee par l'utilisateur

## Code actuel (probleme identifie)
- [ ] Utilise la convention de nommage du test existant sinon celle ci : `test_<methode>_<scenario>_<resultat_attendu>`
- [ ] Base toi sur les tests déjà existants

## Contraintes
- [ ] Utilise la convention de nommage du test existant sinon celle ci : `test_<methode>_<scenario>_<resultat_attendu>`
- [ ] Utilise la version de junit-4.13
- [ ] Ne pas mettre d'accent dans les commentaires
- [ ] Applique le pattern AAA (Arrange, Act, Assert) avec des commentaires séparant chaque section
- [ ] Moins de Mocks possible
- [ ] Les tests existants doivent continuer à passer


## Resultat attendu
1. Applique les modifications directement dans les fichiers.
2. Conserve le comportement fonctionnel à l'identique.
3. Respecte les conventions et patterns du projet existant.
4. Signale les tests a� adapter ou a creer.
5. Liste les risques de regression identifies.
6. Les tests doivent être concis, non repetitifs et s'éxécutés sans erreurs
7. Un tableau récapitulatif du taux de couverture estimé par fonction
8. Les cas non testables automatiquement (nécessitant des tests d'intégration)
9. Des suggestions pour ameliorer la testabilite du code source si necessaire

## Execution
 - [ ] Execute tous les tests pour valider tes modifications.
 - [ ] Si un test echoue, corrige automatquement le ou les tests en erreurs