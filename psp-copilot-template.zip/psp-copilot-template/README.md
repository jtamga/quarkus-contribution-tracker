# README

Ce depot sert de point d'entree pour les personnalisations Copilot du projet PSP. Le dossier `.github/` contient principalement des instructions globales, des agents specialises et quelques prompts reutilisables.

## Vue d'ensemble

| Emplacement | Role | Utilisation |
|---|---|---|
| `.github/copilot-instructions.md` | Instructions globales du projet pour Copilot | Charge automatiquement le contexte, les conventions et les regles de travail du projet |
| `.github/agents/refactoring-mikado.agent.md` | Agent de refactoring incremental Java/TypeScript | A invoquer pour preparer ou executer un refactoring par petites etapes, avec export HTML possible du plan |
| `.github/agents/security-agent.md` | Agent d'analyse securite TypeScript/Vue.js | A invoquer pour auditer un module et produire un rapport de securite |
| `.github/prompts/analyse-bug.prompt.md` | Prompt generique d'analyse de bug | A utiliser pour structurer un diagnostic de bug front, back, API ou batch |
| `.github/prompts/generate-unit-test.prompt.md` | Prompt de generation de tests unitaires Java | A utiliser pour demander la creation de tests sur une classe cible |
| `.github/prompts/refactoring-ts.prompt.md` | Prompt de refactoring TypeScript | A utiliser pour cadrer un refactoring TS de maniere stricte |
| `.github/arborescence.md` | Documentation de la structure du projet PSP | A ajouter au contexte quand Copilot a besoin de comprendre les modules et packages |
| `.github/instructions/` | Dossier reserve aux instructions scopees | Actuellement vide |

## Instructions globales

Le fichier `.github/copilot-instructions.md` definit le cadre de travail de Copilot pour PSP_Prescriptions.

### Ce qu'il contient

- le contexte metier du module PSP_Prescriptions ;
- l'architecture multi-module Maven / Java EE ;
- les conventions Java, TypeScript et Less ;
- les commandes Maven et front utiles ;
- les regles d'equipe a respecter.

### Impact concret

Copilot est cense s'appuyer dessus pour :

- repondre en francais ;
- respecter l'architecture en couches ;
- eviter de modifier les fichiers generes ;
- ajouter des tests sur le code metier ;
- deleguer la logique metier aux bonnes couches.

### Comment l'utiliser

Rien a faire de special pour ce fichier : il sert d'instruction de base du depot.

Si tu veux enrichir le contexte dans une conversation, tu peux aussi joindre explicitement des fichiers, par exemple :

```text
#file:.github/copilot-instructions.md
#file:.github/arborescence.md
```

## Agents disponibles

Les agents personnalises sont definis dans `.github/agents/`.

### Refactoring-Mikado

**Fichier** : `.github/agents/refactoring-mikado.agent.md`

**Description concise**

Agent dedie aux refactorings incrementaux Java et TypeScript selon la methode Mikado : petites etapes, validation frequente, reduction du risque de regression.

**Quand l'utiliser**

- pour decouper un refactoring complexe ;
- pour identifier les dependances et obstacles ;
- pour obtenir un plan testable avec rollback ;
- pour generer un plan de refactoring exportable dans un fichier HTML.

**Exemples d'utilisation**

```text
Refactor Mikado: extraire la logique de validation de ProductService
Mikado: plan pour remplacer any par des types stricts dans le module web
Execute Mikado pour PSP_PrescriptionsWeb
Refactor Mikado: extraire la logique de validation et ecris le plan dans docs/mikado-plan.html
```

**Ce qu'il produit**

- un resume executif ;
- les obstacles identifies ;
- un graphe Mikado simplifie ;
- des etapes incrementales ;
- des tests et commandes de verification ;
- des propositions de patchs ou de commits ;
- optionnellement, un plan structure dans un fichier HTML fourni par l'utilisateur.

**Export HTML**

Si un chemin de fichier HTML est fourni dans la demande, l'agent peut ecrire le plan Mikado dans ce fichier.

Exemple :

```text
Execute Mikado pour PSP_PrescriptionsWeb et exporte le plan dans refactoring/report.html
```

Le fichier genere doit contenir les sections principales du plan et utiliser les marqueurs `<!-- MIKADO_PLAN_START -->` et `<!-- MIKADO_PLAN_END -->` pour faciliter les mises a jour.

### SecurityAgent

**Fichier** : `.github/agents/security-agent.md`

**Description concise**

Agent d'analyse securite cible sur du code TypeScript et Vue.js. Il inspecte le code, releve les vulnerabilites potentielles et produit un rapport structure.

**Quand l'utiliser**

- pour auditer un module front ;
- pour detecter des failles courantes ;
- pour obtenir des recommandations de remediation priorisees.

**Exemple d'utilisation**

```text
Analyse securite pour PSP_PrescriptionsWeb/src
Analyse securite pour src/api
```

**Ce qu'il produit**

- un resume executif ;
- la liste des vulnerabilites avec gravite ;
- une revue des bonnes pratiques ;
- une analyse des dependances ;
- des actions a entreprendre.

**Limite importante**

L'agent fait surtout une revue statique par lecture du code. Les scans SCA/CVE, conteneurs ou IaC restent a lancer avec des outils externes si besoin.

## Prompts utiles

Ces fichiers ne sont pas des agents au sens strict, mais des cadres de demande reutilisables.

### analyse-bug

**Fichier** : `.github/prompts/analyse-bug.prompt.md`

**Usage**

A utiliser pour analyser un bug applicatif de maniere structuree, quel que soit le type de composant concerne.

**Cas couverts**

- bug front-end ;
- bug back-end ;
- bug API ;
- bug batch ;
- bug lie a la configuration ou a l'environnement.

**Exemple**

```text
Analyse ce bug avec le prompt analyse-bug.
Description du bug : l'ecran reste vide apres validation.
Comportement attendu : la liste des prescriptions doit s'afficher.
Etapes de reproduction : ...
Logs : ...
Code suspect : ...
```

### generate-unit-test

**Fichier** : `.github/prompts/generate-unit-test.prompt.md`

**Usage**

A utiliser pour demander la generation de tests unitaires Java robustes, avec compilation et reexecution jusqu'a stabilite.

**Exemple**

```text
Genere des tests unitaires pour la classe PrescriptionService en suivant le prompt generate-unit-test.
```

### refactoring-typescript

**Fichier** : `.github/prompts/refactoring-ts.prompt.md`

**Usage**

A utiliser pour cadrer un refactoring TypeScript incremental, oriente lisibilite, typage et preservation du comportement fonctionnel.

**Exemple**

```text
Applique le prompt refactoring-typescript sur le module de saisie des prescriptions, portee strictement locale.
```

**Point notable**

Le prompt demande de confirmer la portee du refactoring avant modification, ce qui est utile pour eviter une propagation trop large.

## Recommandation d'usage

- utiliser `copilot-instructions.md` comme cadre par defaut ;
- ajouter `arborescence.md` au contexte quand la structure du projet compte ;
- utiliser `analyse-bug` pour cadrer une investigation avant correction ;
- utiliser `Refactoring-Mikado` pour un changement structurel ;
- utiliser `SecurityAgent` pour un audit securite front ;
- utiliser les prompts pour des demandes tres ciblees.
