# README

Ce depot sert de point d'entree pour les personnalisations Copilot du projet PSP. Le dossier `.github/` contient principalement des instructions globales, des agents specialises et quelques prompts reutilisables.

## Vue d'ensemble

| Emplacement                                         | Role                                             | Utilisation                                                                                                              |
| --------------------------------------------------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------ |
| `.github/copilot-instructions.md`                   | Instructions globales du projet pour Copilot     | Charge automatiquement le contexte, les conventions et les regles de travail du projet                                   |
| `.github/agents/generate-junit-skeleton.agent.md`   | Agent de generation de squelette de tests JUnit  | A invoquer pour produire rapidement une classe de test Java compileable, adaptee au projet (JUnit 4/5, unit/integration) |
| `.github/agents/refactoring-mikado.agent.md`        | Agent de refactoring incremental Java/TypeScript | A invoquer pour preparer ou executer un refactoring par petites etapes, avec export HTML possible du plan                |
| `.github/agents/security-agent.md`                  | Agent d'analyse securite TypeScript/Vue.js       | A invoquer pour auditer un module et produire un rapport de securite                                                     |
| `.github/prompts/analyse-bug.prompt.md`             | Prompt generique d'analyse de bug                | A utiliser pour structurer un diagnostic de bug front, back, API ou batch                                                |
| `.github/prompts/generate-unit-test.prompt.md`      | Prompt de generation de tests unitaires Java     | A utiliser pour demander la creation de tests sur une classe cible                                                       |
| `.github/prompts/generate-junit-skeleton.prompt.md` | Prompt de generation de squelette JUnit          | A utiliser pour produire un squelette de classe de test sans logique metier                                              |
| `.github/prompts/refactoring-ts.prompt.md`          | Prompt de refactoring TypeScript                 | A utiliser pour cadrer un refactoring TS de maniere stricte                                                              |
| `.github/arborescence.md`                           | Documentation de la structure du projet PSP      | A ajouter au contexte quand Copilot a besoin de comprendre les modules et packages                                       |
| `.github/instructions/`                             | Dossier reserve aux instructions scopees         | Actuellement vide                                                                                                        |

## Instructions globales

Le fichier `.github/copilot-instructions.md` definit le cadre de travail de Copilot pour PSP_Prescriptions.

### Ce qu'il contient

- le contexte metier du module PSP_Prescriptions ;
- l'architecture multi-module Maven / Java EE ;
- les conventions Java, TypeScript et Less ;
- les commandes Maven et front utiles ;
- les regles d'equipe a respecter.

### Impact concret

Copilot est cense s'appuyer dessus pour :

- repondre en francais ;
- respecter l'architecture en couches ;
- eviter de modifier les fichiers generes ;
- ajouter des tests sur le code metier ;
- deleguer la logique metier aux bonnes couches.

### Comment l'utiliser

Rien a faire de special pour ce fichier : il sert d'instruction de base du depot.

Si tu veux enrichir le contexte dans une conversation, tu peux aussi joindre explicitement des fichiers, par exemple :

```text
#file:.github/copilot-instructions.md
#file:.github/arborescence.md
```

## Agents disponibles

Les agents personnalises sont definis dans `.github/agents/`.

### Activation rapide

Pour activer un agent personnalise dans VS Code :

1. verifier que le fichier agent est present dans `.github/agents/` ;
2. enregistrer les modifications puis executer la commande `Developer: Reload Window` ;
3. ouvrir Copilot Chat ;
4. passer en mode Agent ;
5. selectionner l agent dans la liste (exemple : `Generate-JUnit-Skeleton`) ;
6. envoyer la demande avec le contexte necessaire (classe Java cible, chemin, contraintes).

Exemple de demande :

```text
Genere un squelette de test pour src/main/java/com/example/UserService.java
```

Depannage rapide si l agent n apparait pas :

- verifier le frontmatter YAML (separateurs `---`, champs `name` et `description`) ;
- verifier l emplacement exact du fichier dans `.github/agents/` ;
- relancer `Developer: Reload Window`.

### Generate-JUnit-Skeleton

**Fichier** : `.github/agents/generate-junit-skeleton.agent.md`

**Description concise**

Agent dedie a la generation de squelette de tests Java. Il detecte les conventions du projet et adapte automatiquement :

- la version JUnit (4 ou 5) ;
- le type de test (unit ou integration) ;
- le nommage de la classe de test ;
- le chemin de sortie cible.

**Quand l'utiliser**

- pour demarrer rapidement un nouveau test sans ecrire tout le boilerplate ;
- pour respecter les conventions locales avant implementation des assertions ;
- pour produire un squelette compilable sans logique metier.

**Exemples d'utilisation**

```text
Genere un squelette de test pour la classe PrescriptionService
Genere un squelette JUnit pour src/main/java/com/example/UserService.java
```

**Ce qu'il produit**

- une classe de test complete ;
- une methode de test par methode publique ;
- une structure Given / When / Then ;
- des placeholders a implementer ensuite.

### Refactoring-Mikado

**Fichier** : `.github/agents/refactoring-mikado.agent.md`

**Description concise**

Agent dedie aux refactorings incrementaux Java et TypeScript selon la methode Mikado : petites etapes, validation frequente, reduction du risque de regression.

**Quand l'utiliser**

- pour decouper un refactoring complexe ;
- pour identifier les dependances et obstacles ;
- pour obtenir un plan testable avec rollback ;
- pour generer un plan de refactoring exportable dans un fichier HTML.

**Exemples d'utilisation**

```text
Refactor Mikado: extraire la logique de validation de ProductService
Mikado: plan pour remplacer any par des types stricts dans le module web
Execute Mikado pour PSP_PrescriptionsWeb
Refactor Mikado: extraire la logique de validation et ecris le plan dans docs/mikado-plan.html
```

**Ce qu'il produit**

- un resume executif ;
- les obstacles identifies ;
- un graphe Mikado simplifie ;
- des etapes incrementales ;
- des tests et commandes de verification ;
- des propositions de patchs ou de commits ;
- optionnellement, un plan structure dans un fichier HTML fourni par l'utilisateur.

**Export HTML**

Si un chemin de fichier HTML est fourni dans la demande, l'agent peut ecrire le plan Mikado dans ce fichier.

Exemple :

```text
Execute Mikado pour PSP_PrescriptionsWeb et exporte le plan dans refactoring/report.html
```

Le fichier genere doit contenir les sections principales du plan et utiliser les marqueurs `<!-- MIKADO_PLAN_START -->` et `<!-- MIKADO_PLAN_END -->` pour faciliter les mises a jour.

### SecurityAgent

**Fichier** : `.github/agents/security-agent.md`

**Description concise**

Agent d'analyse securite cible sur du code TypeScript et Vue.js. Il inspecte le code, releve les vulnerabilites potentielles et produit un rapport structure.

**Quand l'utiliser**

- pour auditer un module front ;
- pour detecter des failles courantes ;
- pour obtenir des recommandations de remediation priorisees.

**Exemple d'utilisation**

```text
Analyse securite pour PSP_PrescriptionsWeb/src
Analyse securite pour src/api
```

**Ce qu'il produit**

- un resume executif ;
- la liste des vulnerabilites avec gravite ;
- une revue des bonnes pratiques ;
- une analyse des dependances ;
- des actions a entreprendre.

**Limite importante**

L'agent fait surtout une revue statique par lecture du code. Les scans SCA/CVE, conteneurs ou IaC restent a lancer avec des outils externes si besoin.

## Prompts utiles

Ces fichiers ne sont pas des agents au sens strict, mais des cadres de demande reutilisables.

### Activation rapide (prompts)

Pour utiliser un prompt personnalise dans Copilot Chat :

1. verifier que le fichier existe dans `.github/prompts/` ;
2. ouvrir Copilot Chat (mode Ask ou Edit) ;
3. appeler explicitement le prompt dans la demande ;
4. fournir le contexte metier, les fichiers cibles et le resultat attendu.

Exemple :

```text
Utilise le prompt generate-unit-test pour la classe PrescriptionService.
Contrainte : conserver les conventions de test existantes.
```

Depannage rapide :

- verifier le nom exact du fichier prompt dans `.github/prompts/` ;
- reformuler la demande en citant explicitement le prompt ;
- ajouter les fichiers de contexte dans le chat si necessaire.

### analyse-bug

**Fichier** : `.github/prompts/analyse-bug.prompt.md`

**Usage**

A utiliser pour analyser un bug applicatif de maniere structuree, quel que soit le type de composant concerne.

**Cas couverts**

- bug front-end ;
- bug back-end ;
- bug API ;
- bug batch ;
- bug lie a la configuration ou a l'environnement.

**Exemple**

```text
Analyse ce bug avec le prompt analyse-bug.
Description du bug : l'ecran reste vide apres validation.
Comportement attendu : la liste des prescriptions doit s'afficher.
Etapes de reproduction : ...
Logs : ...
Code suspect : ...
```

### generate-unit-test

**Fichier** : `.github/prompts/generate-unit-test.prompt.md`

**Usage**

A utiliser pour demander la generation de tests unitaires Java robustes, avec compilation et reexecution jusqu'a stabilite.

**Exemple**

```text
Genere des tests unitaires pour la classe PrescriptionService en suivant le prompt generate-unit-test.
```

### generate-junit-skeleton

**Fichier** : `.github/prompts/generate-junit-skeleton.prompt.md`

**Usage**

A utiliser pour produire un squelette de classe de test Java sans logique metier, en adaptant automatiquement JUnit 4/5 et le type de test (unit/integration) selon le projet.

**Exemple**

```text
Utilise le prompt generate-junit-skeleton pour src/main/java/com/example/UserService.java.
Contrainte : generer uniquement le squelette compilable, sans assertions reelles.
```

### refactoring-typescript

**Fichier** : `.github/prompts/refactoring-ts.prompt.md`

**Usage**

A utiliser pour cadrer un refactoring TypeScript incremental, oriente lisibilite, typage et preservation du comportement fonctionnel.

**Exemple**

```text
Applique le prompt refactoring-typescript sur le module de saisie des prescriptions, portee strictement locale.
```

**Point notable**

Le prompt demande de confirmer la portee du refactoring avant modification, ce qui est utile pour eviter une propagation trop large.

## Recommandation d'usage

- utiliser `copilot-instructions.md` comme cadre par defaut ;
- ajouter `arborescence.md` au contexte quand la structure du projet compte ;
- utiliser `analyse-bug` pour cadrer une investigation avant correction ;
- utiliser `generate-junit-skeleton` pour demarrer rapidement un squelette de test Java ;
- utiliser `Refactoring-Mikado` pour un changement structurel ;
- utiliser `SecurityAgent` pour un audit securite front ;
- utiliser les prompts pour des demandes tres ciblees.
