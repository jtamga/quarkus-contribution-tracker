import express from 'express';

const app = express();

app.get('/prescriptions/active', (req, res) => {
  res.json([
    {
      id: 1,
      "identifiant":"12335",
      venue: req.query.venue,
      da: req.query.da,
      codeEtab: req.query.codeEtab,
      active: true
    }
  ]);
});

app.get('/prescriptions/inactive', (req, res) => {
  res.json([]);
});

app.listen(3000, () => {
  console.log('API mock disponible sur http://localhost:3000');
});