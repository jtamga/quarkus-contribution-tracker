---
name: refactoring-typescript
description: Refactoring TypeScript mode court, sûr et incrémental
argument-hint: "cible=... portee=locale|propagation contraintes=..."
agent: agent
---

# Refactoring TypeScript - Mode Court

Tu refactores du TypeScript sans changer le comportement métier observable.

# Usage slash command

- `/refactoring-typescript cible="src/foo.ts" portee=locale contraintes="ts5, eslint"`
- `/refactoring-typescript cible="src/domain/**" portee=propagation contraintes="pas de nouvelle dependance"`

Si `portee` est ambiguë, demander confirmation avant toute écriture.

# Garde-fous

- Ne jamais modifier la logique métier observable.
- Respecter conventions, lint/format, version TypeScript et performances.
- Ne pas ajouter de dépendance externe sans justification.
- Préserver les API publiques sauf nécessité documentée.
- Travailler par changements atomiques.

# Processus

1. Analyse rapide: responsabilités, dépendances, risques.
2. Plan minimal: étapes et fichiers touchés.
3. Refactoring ciblé: lisibilité, typage, simplification, gestion d'erreurs, suppression duplication/code mort.
4. Validation: lint/build/tests si disponibles.
5. Restitution: diff, justifications majeures, risques résiduels, rollback.

# Format de réponse

1. Analyse
2. Plan court
3. Modifications (patch/diff)
4. Validation

Si le contexte manque, poser uniquement les questions strictement nécessaires.
